package front;
import java.*;
import java.sql.*;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.io.*;
import java.text.*;
public class SIGNUPPAGE {
     SIGNUPPAGE(){
         JFrame f = new JFrame("SIGNUP PAGE");
       JLabel lb1 = new JLabel("COIMBATORE INSTITUTE OF TECHNOLOGY");
       lb1.setBounds(700, 30, 1000, 30);
       f.add(lb1);
       lb1.setFont(new Font("calibri",Font.BOLD,36));
       lb1.setForeground(Color.red);
       JLabel b2 = new JLabel("CIVIL AERODROME POST, COIMBATORE-641 014");
       b2.setBounds(800, 70, 600, 40);
       f.add(b2);
       b2.setFont(new Font("calibri",Font.BOLD,25));
       JLabel a2 = new JLabel("DEPARTMENT OF MSC");
       a2.setBounds(890, 110, 400, 40);
       f.add(a2);
       a2.setFont(new Font("calibri",Font.ITALIC,22));
       JLabel lb2 = new JLabel("STUDENT NAME");
       lb2.setBounds(100, 200, 300, 20);
       f.add(lb2);
       lb2.setFont(new Font("calibri",Font.BOLD,20));
       JTextField jt1 = new JTextField();
       jt1.setBounds(300, 200, 250, 20);
       f.add(jt1);
       JLabel lb3 = new JLabel("REGISTER NO");
       lb3.setBounds(100, 300, 300, 20);
       f.add(lb3);
        lb3.setFont(new Font("calibri",Font.BOLD,20));
       JTextField jt2 = new JTextField();
       jt2.setBounds(300, 300, 250, 20);
       f.add(jt2);
       JLabel lb4 = new JLabel("GENDER(M/F)");
       lb4.setBounds(100, 400, 300, 20);
       f.add(lb4);
        lb4.setFont(new Font("calibri",Font.BOLD,20));
        JRadioButton rb1 = new JRadioButton("MALE");
        rb1.setBounds(300, 400, 100, 20);
        f.add(rb1);
        JRadioButton rb2 = new JRadioButton("FEMALE");
        rb2.setBounds(400, 400, 100, 20);
        f.add(rb2);
        JRadioButton rb3 = new JRadioButton("OTHERS");
        rb3.setBounds(500, 400, 100, 20);
        f.add(rb3);
         JTextField jt3 = new JTextField();
        rb1.addActionListener(e -> {jt3.setText("M"); });
        rb2.addActionListener(e -> {jt3.setText("F"); });
        rb3.addActionListener(e -> {jt3.setText("O"); });
       JLabel lb5 = new JLabel("DATE OF BIRTH");
       lb5.setBounds(100, 500, 300, 20);
       f.add(lb5);
        lb5.setFont(new Font("calibri",Font.BOLD,20));
       JTextField jt4 = new JTextField();
       jt4.setBounds(300, 500, 250, 20);
       f.add(jt4);
       JLabel lb6 = new JLabel("EMAIL ID");
       lb6.setBounds(100, 600, 300, 20);
       f.add(lb6);
        lb6.setFont(new Font("calibri",Font.BOLD,20));
        JTextField jt5 = new JTextField();
       jt5.setBounds(300, 600, 250, 20);
       f.add(jt5);
       JLabel lb7 = new JLabel("COURSE ID");
       lb7.setBounds(100, 700, 300, 20);
       f.add(lb7);
        lb7.setFont(new Font("calibri",Font.BOLD,20));
        JRadioButton rb4 = new JRadioButton("MSC SS");
        rb4.setBounds(300, 700, 100, 20);
        f.add(rb4);
        JRadioButton rb5 = new JRadioButton("MSC DS");
        rb5.setBounds(400, 700, 100, 20);
        f.add(rb5);
        JRadioButton rb6 = new JRadioButton("MSC DCS");
        rb6.setBounds(500, 700, 100, 20);
        f.add(rb6);
         JTextField jt13 = new JTextField();
        rb4.addActionListener(e -> {jt13.setText("15"); });
        rb5.addActionListener(e -> {jt13.setText("16"); });
        rb6.addActionListener(e -> {jt13.setText("17"); });
       JLabel lb8 = new JLabel("ADDRESS");
       lb8.setBounds(100, 800, 300, 20);
       f.add(lb8);
        lb8.setFont(new Font("calibri",Font.BOLD,20));
       JTextArea jt7 = new JTextArea();
       jt7.setBounds(300, 800, 300, 50);
       f.add(jt7);
       JLabel background=new JLabel(new ImageIcon("E:/Custom Office Templates/Reg.jfif"));
        background.setBounds(1000, 600, 300, 200);
        f.add(background);
       JLabel lb9 = new JLabel("CONTACT NO");
       lb9.setBounds(100, 900, 300, 20);
       f.add(lb9);
        lb9.setFont(new Font("calibri",Font.BOLD,20));
       JTextField jt8 = new JTextField();
       jt8.setBounds(300, 900, 250, 20);
       f.add(jt8);
       JButton jb1 = new JButton("SUBMIT");
       jb1.setBounds(900, 200, 250, 20);
       f.add(jb1);
       jb1.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
               Connection con = null;
                 Statement stmt = null;
                 try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","520ragavan");                 
                    JOptionPane.showMessageDialog(null,"connection Esatablished to DataBase");
                    stmt = con.createStatement();
                    {                  
                   String t1 = jt1.getText();
                   String t2 = jt2.getText();
                   String t3 = jt3.getText();
                   String t4 = jt4.getText();                 
                   java.sql.Date sqdoj = java.sql.Date.valueOf(t4);
                   String t5 = jt5.getText();
                   String t6 = jt13.getText();
                   String t7 = jt7.getText();
                   String t8 = jt8.getText();
                   String insert_query = "insert into Student"
                        + " (Name, Rollno, Gender,Dob,Emailid,Courseid,Address,Contactno)"
                        + " values (?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement preSt = con.prepareStatement(insert_query);
                preSt.setString(1, t1);
                preSt.setString(2, t2);
                preSt.setString(3, t3);
                preSt.setDate(4, sqdoj);
                preSt.setString(5, t5);
                preSt.setString(6, t6);
                preSt.setString(7, t7);
                preSt.setString(8, t8);
                preSt.executeUpdate();
            }
            {
                ResultSet rs = stmt.executeQuery("select * from Student");
                while (rs.next())
                    System.out.println(rs.getString(1)
                            + "  " + rs.getString(2)
                            + "  " + rs.getString(3)
                            + "  " + rs.getString(4)
                            + "  " + rs.getString(5)
                            + "  " + rs.getString(6)
                            + "  " + rs.getString(7)
                            + "  " + rs.getString(8));
                con.close();
            }
        }
        catch(Exception ex){System.out.println(ex);}
             }});
       JButton jb2 = new JButton("CLEAR");
       jb2.setBounds(900, 300, 250, 20);
       f.add(jb2);
       jb2.addActionListener(e -> { 
           jt1.setText(String.valueOf(" "));
           jt2.setText(String.valueOf(" "));
           jt3.setText(String.valueOf(" "));
           rb1.setText(String.valueOf(" "));
            rb2.setText(String.valueOf(" "));
             rb3.setText(String.valueOf(" "));
           jt4.setText(String.valueOf(" "));
           jt5.setText(String.valueOf(" "));
           jt13.setText(String.valueOf(" "));
           jt7.setText(String.valueOf(" "));
           jt8.setText(String.valueOf(" "));});
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       JButton jb3 = new JButton("EXIT");
       jb3.setBounds(900, 400, 250, 20);
       f.add(jb3);
       jb3.addActionListener(e -> { f.dispose();});
        jb1.setFont(new Font("calibri",Font.BOLD,20));
         jb2.setFont(new Font("calibri",Font.BOLD,20));
          jb3.setFont(new Font("calibri",Font.BOLD,20));
       JMenu menu = new JMenu("RETURN");
       JMenuItem m1 = new JMenuItem("BACK");
       JMenuItem m2 = new JMenuItem("EXIT");
       JMenuBar mb = new JMenuBar();
       menu.add(m1);menu.add(m2);
       mb.add(menu);
       f.setJMenuBar(mb);
       m1.addActionListener(e -> { f.dispose();});
       m2.addActionListener(e -> { f.dispose();});
       menu.setFont(new Font("calibri",Font.BOLD,20));
       m1.setFont(new Font("calibri",Font.BOLD,20));
       m2.setFont(new Font("calibri",Font.BOLD,20));
       f.getContentPane().setBackground(Color.CYAN);
       f.setLayout(null);
       f.setSize(400,500);
       f.setVisible(true); 
    }   
}
 