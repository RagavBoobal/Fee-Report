
package front;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.text.*;

public class LOGINPAGE {
     
    LOGINPAGE()
    {
        JFrame f1 = new JFrame("LOGIN");
       
       JLabel lb1 = new JLabel("COIMBATORE INSTITUTE OF TECHNOLOGY");
       lb1.setBounds(700, 30, 1000, 30);
       f1.add(lb1);
       lb1.setFont(new Font("calibri",Font.BOLD,36));
       lb1.setForeground(Color.red);
       
       JLabel b2 = new JLabel("CIVIL AERODROME POST, COIMBATORE-641 014");
       b2.setBounds(800, 70, 600, 40);
       f1.add(b2);
       b2.setFont(new Font("calibri",Font.BOLD,25));
       
       JLabel a2 = new JLabel("DEPARTMENT OF MSC");
       a2.setBounds(890, 110, 400, 40);
       f1.add(a2);
       a2.setFont(new Font("calibri",Font.ITALIC,22));
       
       JLabel lb2 = new JLabel("STUDENT NAME");
       lb2.setBounds(100, 200, 300, 20);
       f1.add(lb2);
       lb2.setFont(new Font("calibri",Font.BOLD,20));
       
       JTextField jt1 = new JTextField();
       jt1.setBounds(300, 200, 250, 20);
       f1.add(jt1);
       
       JLabel lb3 = new JLabel("REGISTER NO");
       lb3.setBounds(100, 300, 300, 20);
       f1.add(lb3);
       lb3.setFont(new Font("calibri",Font.BOLD,20));
       
       JPasswordField jf1 = new JPasswordField();
       jf1.setBounds(300, 300, 250, 20);
       f1.add(jf1);
       
       JButton jb1 = new JButton("SUBMIT");
       jb1.setBounds(100, 400, 100, 20);
       f1.add(jb1);
       jb1.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
                 Connection con = null;
                 try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","520ragavan");
                    JOptionPane.showMessageDialog(null,"connection Esatablished to DataBase");
                    int pwd = Integer.parseInt(jf1.getText());
		    String sql = "select * from Student where Name='"+jt1.getText()+"' and Rollno='"+pwd+"'";
                    PreparedStatement stmt=con.prepareCall(sql);
                    
                    ResultSet rs = stmt.executeQuery();
                    if(rs.next())
                    {
                          JOptionPane.showMessageDialog(null,"LOGIN SUCCESSFULL");
                          String t7 = jt1.getText();
                          String t8 = jf1.getText();
                          String insert_query = "insert into Login"
                        + " (USERNAME, PASSWORD)"
                        + " values (?, ?)";

                            PreparedStatement preSt = con.prepareStatement(insert_query);

                            preSt.setString(1, t7);
                            preSt.setString(2, t8);
                            preSt.executeUpdate();
                          STUDENTPAGE student = new STUDENTPAGE(jt1.getText(),jf1.getText()); 
		          f1.dispose();
                    }
                    else
                    {
                          JOptionPane.showMessageDialog(null,"INVALID USERNAME AND PASSWORD");
                          con.close();
                    }
                  }catch(Exception ex){System.out.println(ex);}
          
             }         
         });
       
       JButton jb2 = new JButton("CLEAR");
       jb2.setBounds(300, 400, 100, 20);
       f1.add(jb2);
       jb2.addActionListener(e -> { 
           jt1.setText(String.valueOf(" "));
           jf1.setText(String.valueOf(" "));});
     
       f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       JButton jb3 = new JButton("EXIT");
       jb3.setBounds(500, 400, 100, 20);
       f1.add(jb3);
       jb3.addActionListener(e -> { f1.dispose();});
       
       JLabel background1=new JLabel(new ImageIcon("E:/Custom Office Templates/g.jfif"));
        background1.setBounds(850, 200, 300, 170);
        f1.add(background1);
        
        JLabel background2=new JLabel(new ImageIcon("E:/Custom Office Templates/H.jfif"));
        background2.setBounds(850, 400, 280, 190);
        f1.add(background2);
        
        JLabel background3 = new JLabel(new ImageIcon("E:/Custom Office Templates/K.jfif"));
        background3.setBounds(1250, 300, 260, 200);
        f1.add(background3);
       
       
       jb1.setFont(new Font("calibri",Font.BOLD,20));
        jb2.setFont(new Font("calibri",Font.BOLD,20));
          jb3.setFont(new Font("calibri",Font.BOLD,20));
          
       JMenu menu = new JMenu("RETURN");
       JMenuItem m1 = new JMenuItem("BACK");
       JMenuItem m2 = new JMenuItem("EXIT");
       JMenuBar mb = new JMenuBar();
       menu.add(m1);menu.add(m2);
       mb.add(menu);
       f1.setJMenuBar(mb);
       m1.addActionListener(e -> { f1.dispose();});
       m2.addActionListener(e -> { f1.dispose();});
       menu.setFont(new Font("calibri",Font.BOLD,20));
       m1.setFont(new Font("calibri",Font.BOLD,20));
       m2.setFont(new Font("calibri",Font.BOLD,20));
          
       f1.getContentPane().setBackground(Color.PINK);
       f1.setLayout(null);
       f1.setSize(400,500);
       f1.setVisible(true);
       
    
    
    }
    
}
