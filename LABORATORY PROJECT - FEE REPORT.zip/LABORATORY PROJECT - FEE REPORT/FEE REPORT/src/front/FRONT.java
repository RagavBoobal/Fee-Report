
package front;
import java.awt.event.*;
import java.awt.*;
import java.*;
import java.io.*;
import javax.swing.*;
import java.sql.*;

public class FRONT  {

    FRONT()
    {
        JFrame frame = new JFrame("LOAD PAGE");
        
        JLabel background=new JLabel(new ImageIcon("E:/Custom Office Templates/CIT.png"));
        background.setBounds(300, 300, 300, 300);
        frame.add(background);
       
       JLabel lb1 = new JLabel("COIMBATORE INSTITUTE OF TECHNOLOGY");
       lb1.setBounds(700, 30, 1000, 30);
       frame.add(lb1);
       lb1.setFont(new Font("calibri",Font.BOLD,36));
       lb1.setForeground(Color.red);
       
       JLabel lb2 = new JLabel("CIVIL AERODROME POST, COIMBATORE-641 014");
       lb2.setBounds(800, 70, 600, 40);
       frame.add(lb2);
       lb2.setFont(new Font("calibri",Font.BOLD,25));
       
       JLabel a2 = new JLabel("DEPARTMENT OF MSC");
       a2.setBounds(890, 110, 400, 40);
       frame.add(a2);
       a2.setFont(new Font("calibri",Font.ITALIC,22));
       
       JLabel area1 = new JLabel("Government aided Autonomous Engineering College and Affliated to Anna University..");
       area1.setBounds(700, 150, 1000, 200);
       frame.add(area1);
       area1.setFont(new Font("Arial",Font.BOLD,20));
       area1.setForeground(Color.BLUE);
       area1.setHorizontalAlignment(SwingConstants.CENTER);
       
       JLabel area2 = new JLabel("Aim of Disseminating Knowlwdge in field of Science and Technology..");
       area2.setBounds(700, 300, 1000, 200);
       frame.add(area2);
       area2.setFont(new Font("arial",Font.BOLD,20));
       area2.setForeground(Color.BLUE);
       area2.setHorizontalAlignment(SwingConstants.CENTER);
        
       JLabel area3 = new JLabel("Boasts of Strong Academic and High quality of research and Consultancy..");
       area3.setBounds(700, 450, 1000, 200);
       frame.add(area3);
       area3.setFont(new Font("arial",Font.BOLD,20));
       area3.setForeground(Color.BLUE);
       area3.setHorizontalAlignment(SwingConstants.CENTER);
       
          
       JMenu menu = new JMenu("CLICK HERE");
       JMenuBar mb = new JMenuBar();
       JMenuItem m1 = new JMenuItem("STUDENT LOGIN");
       JMenuItem m2 = new JMenuItem("STUDENT REGISTERATION");
       JMenuItem m3 = new JMenuItem("ACCOUNTANT LOGIN");
       JMenuItem m4 = new JMenuItem("EXIT");
       menu.add(m1);
       menu.add(m2);
       menu.add(m3);
       menu.add(m4);
       mb.add(menu);
       frame.setJMenuBar(mb);
       
       menu.setFont(new Font("calibri",Font.BOLD,20));
       menu.setForeground(Color.BLACK);
       m1.setFont(new Font("calibri",Font.BOLD,18));
       m2.setFont(new Font("calibri",Font.BOLD,18));
       m3.setFont(new Font("calibri",Font.BOLD,18));
       m4.setFont(new Font("calibri",Font.BOLD,20));
       
       m1.addActionListener(new ActionListener() {
                        @Override
			public void actionPerformed(ActionEvent arg0) {
				LOGINPAGE login = new LOGINPAGE(); 
				
			}
		});
       m2.addActionListener(new ActionListener() {
                        @Override
			public void actionPerformed(ActionEvent arg0) {
				SIGNUPPAGE login = new SIGNUPPAGE(); 
				
			}
		});
    
       m3.addActionListener(new ActionListener() {
                        @Override
			public void actionPerformed(ActionEvent arg0) {
                            JFrame ff = new JFrame("ACCOUNTANT LOGIN");
                            JLabel background=new JLabel(new ImageIcon("E:/Custom Office Templates/CIT.png"));
                            background.setBounds(300, 300, 300, 300);
                            ff.add(background);


                           JLabel lb1 = new JLabel("COIMBATORE INSTITUTE OF TECHNOLOGY");
                           lb1.setBounds(700, 30, 1000, 30);
                           ff.add(lb1);
                           lb1.setFont(new Font("calibri",Font.BOLD,36));
                           lb1.setForeground(Color.red);

                           JLabel lb2 = new JLabel("CIVIL AERODROME POST, COIMBATORE-641 014");
                           lb2.setBounds(800, 70, 600, 40);
                           ff.add(lb2);
                           lb2.setFont(new Font("calibri",Font.BOLD,25));

                           JLabel a2 = new JLabel("DEPARTMENT OF MSC");
                           a2.setBounds(890, 100, 400, 40);
                           ff.add(a2);
                           a2.setFont(new Font("calibri",Font.ITALIC,22));
                           
                           JLabel a21 = new JLabel("ACCOUNTANT LOGIN");
                           a21.setBounds(920, 130, 400, 40);
                           ff.add(a21);
                           a21.setFont(new Font("calibri",Font.ITALIC,22));
                           
                            JLabel lb3 = new JLabel("ENTER PASSWORD ");
                            lb3.setBounds(700, 400, 300, 20);
                            ff.add(lb3);
                            lb3.setFont(new Font("calibri",Font.BOLD,20));
                           
                            JPasswordField j1 = new JPasswordField();
                            j1.setBounds(900, 400, 150, 20);
                            ff.add(j1);
                            JButton b1 = new JButton("SUBMIT");
                            b1.setBounds(800, 550, 150, 20);
                            ff.add(b1);
                            JLabel background1=new JLabel(new ImageIcon("E:/Custom Office Templates/acc.jpg"));
                            background1.setBounds(1200, 300, 300, 200);
                            ff.add(background1);
                            b1.setFont(new Font("calibri",Font.BOLD,20));
                            b1.addActionListener(e -> {
                            if(j1.getText()== "ADMIN")
                            {
                                 
                                JOptionPane.showMessageDialog(null,"INVALID PASSWORD");
                            }
                            else
                            {
                               INFORMATION info = new INFORMATION();   
                            }});
                             JMenu menu = new JMenu("RETURN");
                            JMenuItem m1 = new JMenuItem("BACK");
                            JMenuItem m2 = new JMenuItem("EXIT");
                            JMenuBar mb = new JMenuBar();
                            menu.add(m1);menu.add(m2);
                            mb.add(menu);
                            ff.setJMenuBar(mb);
                            m1.addActionListener(e -> { ff.dispose();});
                            m2.addActionListener(e -> { ff.dispose();});
                            menu.setFont(new Font("calibri",Font.BOLD,20));
                            m1.setFont(new Font("calibri",Font.BOLD,20));
                            m2.setFont(new Font("calibri",Font.BOLD,20));
                            ff.setLayout(null);
                            ff.getContentPane().setBackground(Color.cyan);
                            ff.setSize(300,300);
                            ff.setVisible(true);
				
				
			}
		});
      
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       m4.addActionListener(e -> { frame.dispose();});
       
       frame.getContentPane().setBackground(Color.cyan);
       frame.setLayout(null);
       frame.setSize(400,500);
       frame.setVisible(true);
       
       
        
    }
    public static void main(String[] args) {
     FRONT fr = new FRONT();
       
    }
}
 