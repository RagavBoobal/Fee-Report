package front;
import java.*;
import java.text.*;
import javax.swing.*;
import java.util.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date.*;
public class PAYMENT extends JFrame{   
    PAYMENT(String r2,String r3)
    {
        JLabel lb1 = new JLabel("COIMBATORE INSTITUTE OF TECHNOLOGY");
       lb1.setBounds(700, 30, 1000, 30);
       add(lb1);
       lb1.setFont(new Font("calibri",Font.BOLD,36));
       lb1.setForeground(Color.red);
       JLabel b2 = new JLabel("CIVIL AERODROME POST, COIMBATORE-641 014");
       b2.setBounds(800, 70, 600, 40);
       add(b2);
       b2.setFont(new Font("calibri",Font.BOLD,25));
       JLabel a2 = new JLabel("DEPARTMENT OF MSC");
       a2.setBounds(890, 110, 400, 40);
       add(a2);
       a2.setFont(new Font("calibri",Font.ITALIC,22));
      JLabel lb6 = new JLabel("SEMESTER NO");
       lb6.setBounds(100, 200, 300, 20);
       add(lb6);
        lb6.setFont(new Font("calibri",Font.BOLD,20));
       JTextField jt2 = new JTextField();
       jt2.setBounds(300, 200, 250, 20);
       add(jt2);
       JLabel l1,lb4,l2,lb5;
                l1 = new JLabel("STUDENT NAME ");
                l1.setBounds(700, 200, 300, 20);
                add(l1);
                l1.setFont(new Font("calibri",Font.BOLD,22));
                l1.setForeground(Color.BLACK);
                lb4 = new JLabel(r2);
                lb4.setBounds(900, 200, 300, 20);
                add(lb4);
                lb4.setFont(new Font("calibri",Font.BOLD,22));
                lb4.setForeground(Color.BLACK);
                l2 = new JLabel("STUDENT ROLLNO ");
                l2.setBounds(700, 300, 300, 20);
                add(l2);
                l2.setFont(new Font("calibri",Font.BOLD,22));
                l2.setForeground(Color.BLACK);
                lb5 = new JLabel(r3);
                lb5.setBounds(900, 300, 300, 20);
                add(lb5);
                lb5.setFont(new Font("calibri",Font.BOLD,22));
                lb5.setForeground(Color.BLACK);
       JLabel b3 = new JLabel("NO.OF.ARREARS");
       b3.setBounds(100, 300, 300, 20);
       add(b3);
       b3.setFont(new Font("calibri",Font.BOLD,20));
       JTextField j2 = new JTextField();
       j2.setBounds(300, 300, 250, 20);
       add(j2);
       String a1="0";
       JLabel b4 = new JLabel("PAYMENT MODE");
       b4.setBounds(100, 400, 300, 20);
       add(b4);
       b4.setFont(new Font("calibri",Font.BOLD,20));    
        JRadioButton rb4 = new JRadioButton("CASH");
        rb4.setBounds(300, 400, 100, 20);
        add(rb4);        
        JRadioButton rb5 = new JRadioButton("CHEQUE");
        rb5.setBounds(450, 400, 100, 20);
        add(rb5);        
         JRadioButton rb6 = new JRadioButton("DD");
        rb6.setBounds(600, 400, 100, 20);
        add(rb6);        
        JRadioButton rb7 = new JRadioButton("ONLINE");
        rb7.setBounds(750, 400, 100, 20);
        add(rb7);
         JTextField jt13 = new JTextField();
        rb4.addActionListener(e -> {jt13.setText("CASH"); });
        rb5.addActionListener(e -> {jt13.setText("CHEQUE"); });
        rb6.addActionListener(e -> {jt13.setText("DD"); });
         rb7.addActionListener(e -> {jt13.setText("ONLINE"); });        
       Date d1 = new Date(2020,05,25);
       Date d2 = new Date(2020,04,24);       
       JLabel background1=new JLabel(new ImageIcon("E:/Custom Office Templates/payment.jpg"));
       background1.setBounds(1300, 600, 310, 170);
       add(background1);      
       boolean a = d2.after(d1);
       String v;
      JButton jb1 =  new JButton("PAY");
       jb1.setBounds(400, 800, 100, 20);
       add(jb1);
      JLabel lb10 = new JLabel("1");
         JLabel lb11 = new JLabel("2020-05-25");
         JLabel lb12 = new JLabel("2020-04-18");
           JLabel lb13 = new JLabel("PAID");
             JLabel lb14 = new JLabel("00");
               JLabel lb15 = new JLabel(r3);
       JMenu menu = new JMenu("RETURN");
       JMenuItem m1 = new JMenuItem("BACK");
       JMenuItem m2 = new JMenuItem("EXIT");
       JMenuBar mb = new JMenuBar();
       menu.add(m1);menu.add(m2);
       mb.add(menu);
       setJMenuBar(mb);
       m1.addActionListener(e -> { dispose();});
       m2.addActionListener(e -> { dispose();});
       menu.setFont(new Font("calibri",Font.BOLD,20));
       m1.setFont(new Font("calibri",Font.BOLD,20));
       m2.setFont(new Font("calibri",Font.BOLD,20));
       getContentPane().setBackground(Color.CYAN);
       setLayout(null);
       setSize(400,500);
       setVisible(true);       
       int v1;
       if((a==true)||(j2.getText()!=a1))
       {          
            v = "66500";
            v1 = 1500;          
       }
       else
       {          
            v = "65000";
            v1 = 0;
       }      
         jb1.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
                 Connection con = null;
                 Statement stmt = null;
                 try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","520ragavan");
                    JOptionPane.showMessageDialog(null,"connection Esatablished to DataBase");
                    stmt = con.createStatement();
                    { String sql = "UPDATE semesterFees SET semFees = 'PAID' , fineAmount = '"+v1+"'  where studentID = '"+r3+"'";
                       stmt.executeUpdate(sql);
                      String sql1 = "UPDATE examFees SET examfeesStatus = 'PAID' , fineAmount = '"+v1+"' where studentID = '"+r3+"'";
                       stmt.executeUpdate(sql1);
                     } 
        }
        catch(Exception ex){System.out.println(ex);}
           }            
         });       
       jb1.addActionListener(e -> {
           REPORT report = new REPORT(r2,r3,v);           
       });
    }    
}
