/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package front;
import java.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.*;

/**
 *
 * @author ragav
 */
public class SEMESTERFEES extends JFrame {
    
    SEMESTERFEES(String r1)
    {
       
       JLabel lb1,b2;
       JLabel lb4,lb5,lb6,lb7,lb8,lb9;
       JLabel l1,l2,l3,l4,l5,l6,l7,l8;
        Connection con = null;
                 try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","520ragavan");
                    JOptionPane.showMessageDialog(null,"connection Esatablished to DataBase");
		    String sql = "select * from semesterFees where studentID='"+r1+"'";
                    PreparedStatement stmt=con.prepareCall(sql);
                    ResultSet rs = stmt.executeQuery();
                    if(rs.next())
                    {
                          lb1 = new JLabel("COIMBATORE INSTITUTE OF TECHNOLOGY");
                          lb1.setBounds(700, 30, 1000, 30);
                          add(lb1);
                          lb1.setFont(new Font("calibri",Font.BOLD,36));
                          lb1.setForeground(Color.red);
       
                          b2 = new JLabel("CIVIL AERODROME POST, COIMBATORE-641 014");
                          b2.setBounds(800, 70, 600, 40);
                          add(b2);
                          b2.setFont(new Font("calibri",Font.BOLD,25));
                          
                          JLabel a2 = new JLabel("DEPARTMENT OF MSC");
                            a2.setBounds(890, 110, 400, 40);
                            add(a2);
                            a2.setFont(new Font("calibri",Font.ITALIC,22));
                            
                            JLabel background1=new JLabel(new ImageIcon("E:/Custom Office Templates/fee2.png"));
                            background1.setBounds(800, 300, 300, 200);
                            add(background1);
                            
                            JLabel background2=new JLabel(new ImageIcon("E:/Custom Office Templates/fee1.jpg"));
                            background2.setBounds(1200, 300, 300, 170);
                            add(background2);
                          
                          l1 = new JLabel("SEMESTER NO ");
                          l1.setBounds(100, 150, 300, 20);
                          add(l1);
                          l1.setFont(new Font("arial",Font.BOLD,22));
                          l1.setForeground(Color.BLUE);
                        
                          lb4 = new JLabel(rs.getString(1));
                          lb4.setBounds(300, 150, 300, 20);
                          add(lb4);
                          lb4.setFont(new Font("arial",Font.BOLD,22));
                          lb4.setForeground(Color.BLUE);
                          
                           l2 = new JLabel("STUDENT ID");
                          l2.setBounds(100, 200, 300, 20);
                          add(l2);
                          l2.setFont(new Font("arial",Font.BOLD,22));
                          l2.setForeground(Color.BLUE);
               
                           lb5 = new JLabel(rs.getString(2));
                           lb5.setBounds(300, 200, 300, 20);
                           add(lb5);
                           lb5.setFont(new Font("arial",Font.BOLD,22));
                           lb5.setForeground(Color.BLUE);
                           
                           l3 = new JLabel("DUE DATE ");
                           l3.setBounds(100, 250, 300, 20);
                           add(l3);
                           l3.setFont(new Font("arial",Font.BOLD,22));
                           l3.setForeground(Color.BLUE);
                
                           lb6 = new JLabel(rs.getString(3));
                           lb6.setBounds(300, 250, 300, 20);
                           add(lb6);
                           lb6.setFont(new Font("arial",Font.BOLD,22));
                           lb6.setForeground(Color.BLUE);
                           
                           l4 = new JLabel("PAID DATE ");
                           l4.setBounds(100, 300, 300, 20);
                           add(l4);
                           l4.setFont(new Font("arial",Font.BOLD,22));
                           l4.setForeground(Color.BLUE);
                          
                           lb7 = new JLabel(rs.getString(4));
                           lb7.setBounds(300, 300, 300, 20);
                           add(lb7);
                           lb7.setFont(new Font("arial",Font.BOLD,22));
                           lb7.setForeground(Color.BLUE);
                           
                           l5 = new JLabel("FEES STATUS ");
                           l5.setBounds(100, 350, 300, 20);
                           add(l5);
                           l5.setFont(new Font("arial",Font.BOLD,22));
                           l5.setForeground(Color.BLUE);
                          
                           lb8 = new JLabel(rs.getString(5));
                           lb8.setBounds(300, 350, 300, 20);
                           add(lb8);
                           lb8.setFont(new Font("arial",Font.BOLD,22));
                           lb8.setForeground(Color.BLUE);
                           
                           l6 = new JLabel("FINE AMOUNT ");
                           l6.setBounds(100, 400, 300, 20);
                           add(l6);
                           l6.setFont(new Font("arial",Font.BOLD,22));
                           l6.setForeground(Color.BLUE);
                
                           lb9 = new JLabel(rs.getString(6));
                           lb9.setBounds(300, 400, 300, 20);
                           add(lb9);
                           lb9.setFont(new Font("arial",Font.BOLD,22));
                           lb9.setForeground(Color.BLUE);
                           
                            JMenu menu = new JMenu("RETURN");
                            JMenuItem m1 = new JMenuItem("BACK");
                            JMenuItem m2 = new JMenuItem("EXIT");
                            JMenuBar mb = new JMenuBar();
                            menu.add(m1);menu.add(m2);
                            mb.add(menu);
                            setJMenuBar(mb);
                            m1.addActionListener(e -> { dispose();});
                            m2.addActionListener(e -> { dispose();});
                            menu.setFont(new Font("calibri",Font.BOLD,20));
                            m1.setFont(new Font("calibri",Font.BOLD,20));
                            m2.setFont(new Font("calibri",Font.BOLD,20));
                           
                           getContentPane().setBackground(Color.CYAN);
                           setLayout(null);
                           setSize(400,500);
                           setVisible(true);
                    }
                    else
                    {
                          JOptionPane.showMessageDialog(null,"FEES NOT YET PAYED");
                          con.close();
                          setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                          dispose();
                    }
                  }catch(Exception ex){System.out.println(ex);}
                 
                 
                 
                    JLabel lb14,lb15,lb16,lb17,lb18,lb19,l19;
                    JLabel l11,l12,l13,l14,l15,l16,l17,l18;
                    Connection con1 = null;
                 try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con1 = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","520ragavan");
                    JOptionPane.showMessageDialog(null,"connection Esatablished to DataBase");
		    String sql1 = "select * from examFees where studentID='"+r1+"'";
                    PreparedStatement stmt1=con.prepareCall(sql1);
                    ResultSet rs = stmt1.executeQuery();
                    if(rs.next())
                    {
                          
                          l11 = new JLabel("ROLL NUMBER");
                          l11.setBounds(100, 500, 300, 20);
                          add(l11);
                          l11.setFont(new Font("arial",Font.BOLD,22));
                          l11.setForeground(Color.BLUE);
                        
                          lb14 = new JLabel(rs.getString(1));
                          lb14.setBounds(300, 500, 300, 20);
                          add(lb14);
                          lb14.setFont(new Font("arial",Font.BOLD,22));
                          lb14.setForeground(Color.BLUE);
                          
                          l12 = new JLabel("NO OF PAPERS");
                          l12.setBounds(100, 550, 300, 20);
                          add(l12);
                          l12.setFont(new Font("arial",Font.BOLD,22));
                          l12.setForeground(Color.BLUE);
               
                          lb15 = new JLabel(rs.getString(2));
                          lb15.setBounds(300, 550, 300, 20);
                          add(lb15);
                          lb15.setFont(new Font("arial",Font.BOLD,22));
                          lb15.setForeground(Color.BLUE);
                           
                          l13 = new JLabel("EXAM FEES ");
                          l13.setBounds(100, 600, 300, 20);
                          add(l13);
                          l13.setFont(new Font("arial",Font.BOLD,22));
                          l13.setForeground(Color.BLUE);
                          
                
                           lb16 = new JLabel(rs.getString(3));
                           lb16.setBounds(300, 600, 300, 20);
                           add(lb16);
                           lb16.setFont(new Font("arial",Font.BOLD,22));
                           lb16.setForeground(Color.BLUE);
                           
                          l14 = new JLabel("DUE DATE ");
                          l14.setBounds(100, 650, 300, 20);
                          add(l14);
                          l14.setFont(new Font("arial",Font.BOLD,22));
                          l14.setForeground(Color.BLUE);
                          
                           lb17 = new JLabel(rs.getString(4));
                           lb17.setBounds(300, 650, 300, 20);
                           add(lb17);
                           lb17.setFont(new Font("arial",Font.BOLD,22));
                           lb17.setForeground(Color.BLUE);
                           
                           l15 = new JLabel("PAID DATE ");
                           l15.setBounds(100, 700, 300, 20);
                           add(l15);
                           l15.setFont(new Font("arial",Font.BOLD,22));
                           l15.setForeground(Color.BLUE);
                          
                           lb18 = new JLabel(rs.getString(5));
                           lb18.setBounds(300, 700, 300, 20);
                           add(lb18);
                           lb18.setFont(new Font("arial",Font.BOLD,22));
                           lb18.setForeground(Color.BLUE);
                           
                            l16 = new JLabel("FEES STATUS");
                            l16.setBounds(100, 750, 300, 20);
                            add(l16);
                            l16.setFont(new Font("arial",Font.BOLD,22));
                            l16.setForeground(Color.BLUE);
                
                           lb19 = new JLabel(rs.getString(6));
                           lb19.setBounds(300, 750, 300, 20);
                           add(lb19);
                           lb19.setFont(new Font("arial",Font.BOLD,22));
                           lb19.setForeground(Color.BLUE);
                           
                           l17 = new JLabel("FINE AMOUNT");
                           l17.setBounds(100, 800, 300, 20);
                           add(l17);
                           l17.setFont(new Font("arial",Font.BOLD,22));
                           l17.setForeground(Color.BLUE);
                           
                           l19 = new JLabel(rs.getString(7));
                           l19.setBounds(300, 800, 300, 20);
                           add(l19);
                           l19.setFont(new Font("arial",Font.BOLD,22));
                           l19.setForeground(Color.BLUE);
                  
                    }
                    else
                    {
                          JOptionPane.showMessageDialog(null,"EXAM FEES NOT YET PAYED");
                          Statement stmt2 = null;
                          stmt2 = con.createStatement();
                           ResultSet r = stmt2.executeQuery("select * from examFees");
               
                 while (r.next())
                    System.out.println(r.getString(1)
                            + "  " + r.getString(2)
                            + "  " + r.getString(3)
                            + "  " + r.getString(4)
                            + "  " + r.getString(5)
                            + "  " + r.getString(6)
                            + "  " + r.getString(7));
                          con.close();
                          
                    }
                  }catch(Exception ex){System.out.println(ex);}
    }
    
}



 