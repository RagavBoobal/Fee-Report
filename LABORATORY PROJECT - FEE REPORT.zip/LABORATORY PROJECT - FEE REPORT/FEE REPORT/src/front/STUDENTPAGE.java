/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package front;
import javax.swing.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.*;

public class STUDENTPAGE {
    
    STUDENTPAGE(String s,String s2)
    {
       JFrame f2 = new JFrame("STUDENT PAGE");
       
       JLabel lb1 = new JLabel("COIMBATORE INSTITUTE OF TECHNOLOGY");
       lb1.setBounds(700, 30, 1000, 30);
       f2.add(lb1);
       lb1.setFont(new Font("calibri",Font.BOLD,36));
       lb1.setForeground(Color.red);
       
       JLabel b2 = new JLabel("CIVIL AERODROME POST, COIMBATORE-641 014");
       b2.setBounds(800, 70, 600, 40);
       f2.add(b2);
       b2.setFont(new Font("calibri",Font.BOLD,25));
       
       JLabel a2 = new JLabel("DEPARTMENT OF MSC");
       a2.setBounds(890, 110, 400, 40);
       f2.add(a2);
       a2.setFont(new Font("calibri",Font.ITALIC,22));
       
       JLabel background1=new JLabel(new ImageIcon("E:/Custom Office Templates/book.png"));
        background1.setBounds(1300, 250, 250, 250);
        f2.add(background1);
       
        JLabel background=new JLabel(new ImageIcon("E:/Custom Office Templates/stu.jfif"));
        background.setBounds(1300, 500, 280, 190);
        f2.add(background);
        
        JLabel background3=new JLabel(new ImageIcon("E:/Custom Office Templates/stud.png"));
        background3.setBounds(800, 375, 230, 230);
        f2.add(background3);
      
       JLabel lb2 = new JLabel(s);
       JLabel lb3 = new JLabel(s2);
       
                 Connection con = null;
                 Statement stmt = null;
                 try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","520ragavan");
                    JOptionPane.showMessageDialog(null,"connection Esatablished to DataBase");
                    stmt = con.createStatement();
                   
            {
              
            JLabel lb4,lb5,lb6,lb7,lb8,lb9,lb10,lb11;
            JLabel l1,l2,l3,l4,l5,l6,l7,l8;
            ResultSet rs = stmt.executeQuery("select * from Student where Name = '"+lb2.getText()+"' and Rollno = '"+lb3.getText()+"'");
            while (rs.next())
            {
                l1 = new JLabel("STUDENT NAME ");
                l1.setBounds(300, 150, 300, 20);
                f2.add(l1);
                l1.setFont(new Font("calibri",Font.BOLD,22));
                l1.setForeground(Color.red);
                
                lb4 = new JLabel(rs.getString(1));
                lb4.setBounds(500, 150, 300, 20);
                f2.add(lb4);
                lb4.setFont(new Font("calibri",Font.BOLD,22));
                lb4.setForeground(Color.red);
               
                l2 = new JLabel("STUDENT ROLLNO ");
                l2.setBounds(300, 250, 300, 20);
                f2.add(l2);
                l2.setFont(new Font("calibri",Font.BOLD,22));
                l2.setForeground(Color.red);
                
                lb5 = new JLabel(rs.getString(2));
                lb5.setBounds(500, 250, 300, 20);
                f2.add(lb5);
                lb5.setFont(new Font("calibri",Font.BOLD,22));
                lb5.setForeground(Color.red);
                
                
                
                l3 = new JLabel("GENDER ");
                l3.setBounds(300, 350, 300, 20);
                f2.add(l3);
                l3.setFont(new Font("calibri",Font.BOLD,22));
                l3.setForeground(Color.red);
                
                lb6 = new JLabel(rs.getString(3));
                lb6.setBounds(500, 350, 300, 20);
                f2.add(lb6);
                lb6.setFont(new Font("calibri",Font.BOLD,22));
                lb6.setForeground(Color.red);
                
                l4 = new JLabel("DOB ");
                l4.setBounds(300, 450, 300, 20);
                f2.add(l4);
                l4.setFont(new Font("calibri",Font.BOLD,22));
                l4.setForeground(Color.red);
                
                lb7 = new JLabel(rs.getString(4));
                lb7.setBounds(500, 450, 300, 20);
                f2.add(lb7);
                lb7.setFont(new Font("calibri",Font.BOLD,22));
                lb7.setForeground(Color.red);
                
                l5 = new JLabel("EMAIL ID ");
                l5.setBounds(300, 550, 300, 20);
                f2.add(l5);
                l5.setFont(new Font("calibri",Font.BOLD,22));
                l5.setForeground(Color.red);
                
                lb8 = new JLabel(rs.getString(5));
                lb8.setBounds(500, 550, 300, 20);
                f2.add(lb8);
                lb8.setFont(new Font("calibri",Font.BOLD,22));
                lb8.setForeground(Color.red);
                
                l6 = new JLabel("COURSE ID ");
                l6.setBounds(300, 650, 300, 20);
                f2.add(l6);
                l6.setFont(new Font("calibri",Font.BOLD,22));
                l6.setForeground(Color.red);
                
                lb9 = new JLabel(rs.getString(6));
                lb9.setBounds(500, 650, 300, 20);
                f2.add(lb9);
                lb9.setFont(new Font("calibri",Font.BOLD,22));
                lb9.setForeground(Color.red);
                
               
                
                l7 = new JLabel("ADDRESS ");
                l7.setBounds(300, 750, 300, 20);
                f2.add(l7);
                l7.setFont(new Font("calibri",Font.BOLD,22));
                l7.setForeground(Color.red);
                
                lb10 = new JLabel(rs.getString(7));
                lb10.setBounds(500, 750, 300, 20);
                f2.add(lb10);
                lb10.setFont(new Font("calibri",Font.BOLD,22));
                lb10.setForeground(Color.red);
                
                l8 = new JLabel("CONTACT NO ");
                l8.setBounds(300, 850, 300, 20);
                f2.add(l8);
                l8.setFont(new Font("calibri",Font.BOLD,22));
                l8.setForeground(Color.red);
                
                lb11 = new JLabel(rs.getString(8));
                lb11.setBounds(500, 850, 300, 20);
                f2.add(lb11);
                lb11.setFont(new Font("calibri",Font.BOLD,22));
                lb11.setForeground(Color.red);

                con.close();
            }}
            

        }
        catch(Exception ex){System.out.println(ex);}
          
       
                 
       JMenuBar mb = new JMenuBar();
       JMenu menu = new JMenu("CLICK HERE");
       JMenuItem m1 = new JMenuItem("FINANCE");
     //  JMenuItem m2 = new JMenuItem(" EXAM FEES STATUS");
       JMenuItem m3 = new JMenuItem("PAY DUES");
      // JMenuItem m4 = new JMenuItem(" INFORMATION");
       JMenuItem m5 = new JMenuItem("EXIT");
       menu.add(m1);
      // menu.add(m2);
       menu.add(m3);
     //  menu.add(m4);
       menu.add(m5);
       mb.add(menu);
       f2.setJMenuBar(mb);
       
       m1.addActionListener(e -> {
           SEMESTERFEES sem = new SEMESTERFEES(lb3.getText());
          
       });
       
     //  m2.addActionListener(e -> {
    //       EXAMCLASS exam = new EXAMCLASS("1831010");
        
     //  });
       
       m3.addActionListener(e -> {
           PAYMENT pay = new PAYMENT(lb2.getText(),lb3.getText());
           
       });
       
  //     m4.addActionListener(e -> {
    //       INFORMATION in = new INFORMATION();
      //     f2.dispose();
       //});
       
       f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       m5.addActionListener(e -> { f2.dispose();});
       
       menu.setFont(new Font("calibri",Font.BOLD,20));
       menu.setForeground(Color.red);
       m1.setFont(new Font("calibri",Font.BOLD,18));
   //    m2.setFont(new Font("calibri",Font.BOLD,18));
       m3.setFont(new Font("calibri",Font.BOLD,18));
   //    m4.setFont(new Font("calibri",Font.BOLD,18));
       m5.setFont(new Font("calibri",Font.BOLD,18));
       m1.setForeground(Color.red);
   //    m2.setForeground(Color.red);
       m3.setForeground(Color.red);
     //  m4.setForeground(Color.red);
       m5.setForeground(Color.red);
       
       f2.getContentPane().setBackground(Color.LIGHT_GRAY);
       f2.setLayout(null);
       f2.setSize(400,500);
       f2.setVisible(true);
    }
    
}

