
package front;

import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class INFORMATION {
    INFORMATION()
    {
       JFrame f3 = new JFrame("SIGNUP PAGE");
       
       JLabel lb1 = new JLabel("COIMBATORE INSTITUTE OF TECHNOLOGY");
       lb1.setBounds(700, 30, 1000, 30);
       f3.add(lb1);
       lb1.setFont(new Font("calibri",Font.BOLD,36));
       lb1.setForeground(Color.red);
       
       JLabel b2 = new JLabel("CIVIL AERODROME POST, COIMBATORE-641 014");
       b2.setBounds(800, 70, 600, 40);
       f3.add(b2);
       b2.setFont(new Font("calibri",Font.BOLD,25));
       
       JLabel a2 = new JLabel("DEPARTMENT OF MSC");
       a2.setBounds(890, 110, 400, 40);
       f3.add(a2);
       a2.setFont(new Font("calibri",Font.ITALIC,22));
       
       DefaultListModel<String> login = new DefaultListModel<>();
       login.addElement("LOGIN USERS");
       
                 Connection con = null;
                 Statement stmt = null;
                 try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","520ragavan");
                    JOptionPane.showMessageDialog(null,"connection Esatablished to DataBase");
                    stmt = con.createStatement();
       
                    ResultSet rs = stmt.executeQuery("select DISTINCT USERNAME,PASSWORD from Login");
                while (rs.next())
                    login.addElement(rs.getString(2));
                  con.close();
                  }catch(Exception ex){System.out.println(ex);}
       
       JList<String> loginlist = new JList<>(login);
       loginlist.setBounds(200, 300, 300, 300);
       loginlist.setFont(new Font("ARIAL",Font.BOLD,19));
       f3.add(loginlist);
       
       DefaultListModel<String> paid = new DefaultListModel<>();
       paid.addElement("FEES PAID ROLL NOS");
        
       
                 Connection con1 = null;
                 Statement stmt1 = null;
                 
                 try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con1 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","520ragavan");
                    JOptionPane.showMessageDialog(null,"connection Esatablished to DataBase");
                    stmt1 = con1.createStatement();
                    
                    ResultSet rs = stmt1.executeQuery("select studentID from examFees where examfeesStatus = 'PAID'");
                while (rs.next())
                    paid.addElement(rs.getString(1));
                  con.close();
                  }catch(Exception ex){System.out.println(ex);}
       
       JList<String> list1 = new JList<>(paid);
       list1.setBounds(700, 300, 300, 300);
       list1.setFont(new Font("ARIAL",Font.BOLD,19));
       f3.add(list1);
       
        DefaultListModel<String> unpaid = new DefaultListModel<>();
        unpaid.addElement("FEES UNPAID ROLL NOS");
       
        
                 Connection con2 = null;
                 Statement stmt2 = null;
                 
                 try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con2 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","520ragavan");
                    JOptionPane.showMessageDialog(null,"connection Esatablished to DataBase");
                    stmt2 = con2.createStatement();
                    
                    ResultSet rs = stmt2.executeQuery("select studentID from examFees where examfeesStatus = 'UNPAID'");
                while (rs.next())
                    unpaid.addElement(rs.getString(1));
                  con.close();
                  }catch(Exception ex){System.out.println(ex);}
       
       JList<String> list2 = new JList<>(unpaid);
       list2.setBounds(1200, 300, 300, 300);
       list2.setFont(new Font("ARIAL",Font.BOLD,19));
       f3.add(list2);
       
       JMenu menu = new JMenu("RETURN");
       JMenuItem m1 = new JMenuItem("BACK");
       JMenuItem m2 = new JMenuItem("EXIT");
       JMenuBar mb = new JMenuBar();
       menu.add(m1);menu.add(m2);
       mb.add(menu);
       f3.setJMenuBar(mb);
       m1.addActionListener(e -> { f3.dispose();});
       m2.addActionListener(e -> { f3.dispose();});
       menu.setFont(new Font("calibri",Font.BOLD,20));
       m1.setFont(new Font("calibri",Font.BOLD,20));
       m2.setFont(new Font("calibri",Font.BOLD,20));
                        
       f3.getContentPane().setBackground(Color.orange);
       f3.setLayout(null);
       f3.setSize(400,500);
       f3.setVisible(true);
    }
    
}
