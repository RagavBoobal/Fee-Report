/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package front;

import java.awt.Color;
import java.*;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;

/**
 *
 * @author ragav
 */
public class EXAMCLASS extends JFrame {
    
    EXAMCLASS(String r2)
    {
        
       
       JLabel lb14,lb15,lb16,lb17,lb18,lb19,l19;
       JLabel l11,l12,l13,l14,l15,l16,l17,l18;
        Connection con = null;
                 try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","520ragavan");
                    JOptionPane.showMessageDialog(null,"connection Esatablished to DataBase");
		    String sql = "select * from examFees where studentID='"+r2+"'";
                    PreparedStatement stmt=con.prepareCall(sql);
                    ResultSet rs = stmt.executeQuery();
                    if(rs.next())
                    {
                          
                          l11 = new JLabel("ROLL NUMBER");
                          l11.setBounds(100, 500, 300, 20);
                          add(l11);
                          l11.setFont(new Font("arial",Font.BOLD,22));
                          l11.setForeground(Color.BLUE);
                        
                          lb14 = new JLabel(rs.getString(1));
                          lb14.setBounds(300, 500, 300, 20);
                          add(lb14);
                          lb14.setFont(new Font("arial",Font.BOLD,22));
                          lb14.setForeground(Color.BLUE);
                          
                          l12 = new JLabel("NO OF PAPERS");
                          l12.setBounds(100, 550, 300, 20);
                          add(l12);
                          l12.setFont(new Font("arial",Font.BOLD,22));
                          l12.setForeground(Color.BLUE);
               
                          lb15 = new JLabel(rs.getString(2));
                          lb15.setBounds(300, 550, 300, 20);
                          add(lb15);
                          lb15.setFont(new Font("arial",Font.BOLD,22));
                          lb15.setForeground(Color.BLUE);
                           
                          l13 = new JLabel("EXAM FEES ");
                          l13.setBounds(100, 600, 300, 20);
                          add(l13);
                          l13.setFont(new Font("arial",Font.BOLD,22));
                          l13.setForeground(Color.BLUE);
                          
                
                           lb16 = new JLabel(rs.getString(3));
                           lb16.setBounds(300, 600, 300, 20);
                           add(lb16);
                           lb16.setFont(new Font("arial",Font.BOLD,22));
                           lb16.setForeground(Color.BLUE);
                           
                          l14 = new JLabel("DUE DATE ");
                          l14.setBounds(100, 650, 300, 20);
                          add(l14);
                          l14.setFont(new Font("arial",Font.BOLD,22));
                          l14.setForeground(Color.BLUE);
                          
                           lb17 = new JLabel(rs.getString(4));
                           lb17.setBounds(300, 650, 300, 20);
                           add(lb17);
                           lb17.setFont(new Font("arial",Font.BOLD,22));
                           lb17.setForeground(Color.BLUE);
                           
                           l15 = new JLabel("PAID DATE ");
                           l15.setBounds(100, 700, 300, 20);
                           add(l15);
                           l15.setFont(new Font("arial",Font.BOLD,22));
                           l15.setForeground(Color.BLUE);
                          
                           lb18 = new JLabel(rs.getString(5));
                           lb18.setBounds(300, 700, 300, 20);
                           add(lb18);
                           lb18.setFont(new Font("arial",Font.BOLD,22));
                           lb18.setForeground(Color.BLUE);
                           
                            l16 = new JLabel("FEES STATUS");
                            l16.setBounds(100, 750, 300, 20);
                            add(l16);
                            l16.setFont(new Font("arial",Font.BOLD,22));
                            l16.setForeground(Color.BLUE);
                
                           lb19 = new JLabel(rs.getString(6));
                           lb19.setBounds(300, 750, 300, 20);
                           add(lb19);
                           lb19.setFont(new Font("arial",Font.BOLD,22));
                           lb19.setForeground(Color.BLUE);
                           
                           l17 = new JLabel("FINE AMOUNT");
                           l17.setBounds(100, 800, 300, 20);
                           add(l17);
                           l17.setFont(new Font("arial",Font.BOLD,22));
                           l17.setForeground(Color.BLUE);
                           
                           l19 = new JLabel(rs.getString(7));
                           l19.setBounds(300, 800, 300, 20);
                           add(l19);
                           l19.setFont(new Font("arial",Font.BOLD,22));
                           l19.setForeground(Color.BLUE);
                  
                    }
                    else
                    {
                          JOptionPane.showMessageDialog(null,"EXAM FEES NOT YET PAYED");
                          con.close();
                          
                    }
                  }catch(Exception ex){System.out.println(ex);}
 }
    
}
